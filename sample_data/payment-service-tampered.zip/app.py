def handle_payment(): return {'tampered': True}
