def handle_payment(): return {'status': 'processed'}
